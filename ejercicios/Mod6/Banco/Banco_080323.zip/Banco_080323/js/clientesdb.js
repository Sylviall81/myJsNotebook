
const clientesdb= [

    // Atributos: (idnumber, nombre, apellido)
    new Cliente ("45960968k","Sandra", "Suárez"),
    new Cliente ("71365220z", "Guillem","López"),
    new Cliente ("15405451v","Valeria", "Olmedo"),
    new Cliente ("45308890c", "Cristobal", "Gutierrez")
];