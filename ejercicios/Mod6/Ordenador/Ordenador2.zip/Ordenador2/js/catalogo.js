
const catalogo = [

    // constructor (marca, modelo, procesador, memoriaRAM, discoDuro)


];

/*("Lenovo", "Idea Pad", "AMD Ryzen 5", "8Gigas","512 GB"), 
("Apple", "MacBook Air", "Apple Silicon M1", "8Gigas","256 GB")*/